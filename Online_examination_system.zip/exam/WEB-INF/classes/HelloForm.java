// Import required java libraries 
import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
 
// Extend HttpServlet class 
public class HelloForm extends HttpServlet { 
  
  // Method to handle POST method request. 
  
   public void doPost(HttpServletRequest request, 
                    HttpServletResponse response) 
            throws ServletException, IOException 
  { 
      // Set response content type 
      response.setContentType("text/html"); 
 
      PrintWriter out = response.getWriter(); 
	  String title = "Student Details";
	  String i1 = request.getParameter("iot");
	  String i2 = request.getParameter("parallel_algo");
	  String i3 = request.getParameter("soft_computing");
      String docType = 
      "<!doctype html public \"-//w3c//dtd html 4.0 " + 
      "transitional//en\">\n";
	  String output = docType + 
                "<html>\n" + 
                "<head><title>" + title + "</title></head>\n" + 
                "<body bgcolor=\"#f0f0f0\">\n" + 
                "<h1>" + title + "</h1>\n" + 
                "<ul>\n" + 
                " <b>Full Name</b>: " 
                + request.getParameter("full_name") + "\n" + "<br>"
                + "<b>Age</b>: " 
                + request.getParameter("age") + "\n" + "<br>"
				+ 
                "<b>Address</b>: " 
                + request.getParameter("address") + "\n" + "<br>" +
                "<b>Semester</b>: " 
                + request.getParameter("sem") + "\n" + "<br>"
				+"<b>Selected Subjects</b>: \n" ;
	if(i1 != null)
		output += i1 + "\t";
	
	if(i2 != null)
		output += i2 + "\t";
	
	if(i3 != null)
		output += i3 + "\t";
	
	output += "</ul>\n" + "</body></html>";
      out.println(output); 
  }

	 
} 