import java.io.*; 
import java.util.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
import java.sql.*; 
  
public class DatabaseEntry extends HttpServlet{ 
     
  public void doPost(HttpServletRequest request, 
                    HttpServletResponse response) 
            throws ServletException, IOException 
			{
      // JDBC driver name and database URL 
      final String JDBC_DRIVER="com.mysql.jdbc.Driver";   
      final String DB_URL="jdbc:mysql://localhost/test"; 
	  Connection conn = null;
	  Statement stmt = null;
 
      //  Database credentials 
      final String USER = "root"; 
      final String PASS = "qwaszx"; 
 
      // Set response content type 
      response.setContentType("text/html"); 
      PrintWriter out = response.getWriter(); 
      String title = "Database Result"; 
      String docType = 
        "<!doctype html public \"-//w3c//dtd html 4.0 " + 
         "transitional//en\">\n"; 
         out.println(docType + 
         "<html>\n" + 
         "<head><title>" + title + "</title></head>\n" + 
         "<body bgcolor=\"#f0f0f0\">\n" + 
         "<h1 align=\"center\">" + title + "</h1>\n"); 
      try{ 
         // Register JDBC driver 
         Class.forName("com.mysql.jdbc.Driver"); 
 
         // Open a connection 
         conn = DriverManager.getConnection(DB_URL,USER,PASS); 
 
         // Execute SQL query 
         stmt = conn.createStatement(); 
         String sql; 
		 int id = Integer.parseInt(request.getParameter("id"));
		 int age = Integer.parseInt(request.getParameter("age"));
		 String first = request.getParameter("first");
		 String last = request.getParameter("last");
         sql = "INSERT INTO student VALUES(?,?,?,?)"; 
         
		 PreparedStatement pst = conn.prepareStatement(sql);
		 pst.setString(1, String.valueOf(id));
		 pst.setString(2, String.valueOf(age));
		 pst.setString(3, first);
		 pst.setString(4, last);
		 
		 pst.executeUpdate();
		 
		 sql = "SELECT id, fname, lname, age FROM Student";
		 ResultSet rs = stmt.executeQuery(sql);
		// Extract data from result set
 
		out.println("<table width=\"400px\" align=\"center\" border=1>");
		out.println("<td align=\"center\"><b>ID</b></td>");
		out.println("<td align=\"center\"><b>First Name</b></td>");
		out.println("<td align=\"center\"><b>Last Name</b></td>");
		out.println("<td align=\"center\"><b>Age</b></td>");
		
		while(rs.next()){
		//Retrieve by column name
		id = rs.getInt("id");
		age = rs.getInt("age");
		first = rs.getString("fname");
		last = rs.getString("lname");
		//Display values
		out.println("<tr><td>" + id + "</td>" + "<td>" + first + "</td>" + "<td>" + last + "</td>" + "<td>" + age + "</td>" + "</tr>");
 
		}
		out.println("</table>");
 
         // Extract data from result set
		 stmt.close(); 
		 pst.close();
         conn.close(); 
      }catch(SQLException se){ 
         //Handle errors for JDBC 
         se.printStackTrace(); 
      }catch(Exception e){ 
         //Handle errors for Class.forName 
         e.printStackTrace(); 
      }finally{ 
         //finally block used to close resources 
         try{ 
            if(stmt!=null) 
               stmt.close(); 
         }catch(SQLException se2){ 
         }// nothing we can do 
         try{ 
            if(conn!=null) 
            conn.close(); 
         }catch(SQLException se){ 
		  se.printStackTrace(); 
         }//end finally try 
      } //end try 
   } 
}